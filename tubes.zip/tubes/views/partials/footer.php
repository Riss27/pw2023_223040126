
<footer class="text-lg-start">
    <div class="container text-center">
        © 2023 Created By: Muhammad Faris Fathur Rohman | 223040126
    </div>
</footer>


  <!-- My JS -->
  <script src="js/script.js"></script>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>

  <!-- AOS JS -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  
  <script>
    AOS.init();
  </script>
</body>

</html>